# game-status-discordbot-selfhosted
self hosted version of game status discord bot
